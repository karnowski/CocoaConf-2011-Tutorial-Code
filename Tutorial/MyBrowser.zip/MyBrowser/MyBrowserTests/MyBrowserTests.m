//
//  MyBrowserTests.m
//  MyBrowserTests
//
//  Created by Christopher Judd on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "MyBrowserTests.h"

@implementation MyBrowserTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MyBrowserTests");
}

@end
