//
//  JSBViewController.h
//  MyBrowser
//
//  Created by Christopher Judd on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSBViewController : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *urlField;
@property (weak, nonatomic) IBOutlet UIWebView *webView;


- (IBAction)browseTo:(id)sender;

@end
